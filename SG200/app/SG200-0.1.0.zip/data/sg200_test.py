import logging
import requests

logging.info("===> Starting sg200 Test Script")

logging.debug("Params for sg200 Test Script:")
logging.debug(params)

response = {}

collector_host = (params.get("connect_ciscosg200_collector_host") or "").strip()
collector_port = str(params.get("connect_ciscosg200_collector_port") or "").strip()
collector_proto = (params.get("connect_ciscosg200_collector_protocol") or "http").strip().lower()
switch_list = (params.get("connect_ciscosg200_switch_list") or "").strip()

# Optional: only used if you later add these fields to system.conf
sg200_username = (params.get("connect_ciscosg200_username") or "").strip()
sg200_password = (params.get("connect_ciscosg200_password") or "").strip()

if not collector_host or not collector_port:
    msg = "Missing collector host or port configuration."
    logging.error("sg200 Test: " + msg)
    response["succeeded"] = False
    response["troubleshooting"] = msg

elif not switch_list:
    msg = "No SG200 switches configured (connect_ciscosg200_switch_list is empty)."
    logging.error("sg200 Test: " + msg)
    response["succeeded"] = False
    response["troubleshooting"] = msg

else:
    # Use the first non-empty IP in the list for testing
    test_ip = None
    for raw_ip in switch_list.split(","):
        ip = raw_ip.strip()
        if ip:
            test_ip = ip
            break

    if not test_ip:
        msg = "No valid SG200 IP found in connect_ciscosg200_switch_list."
        logging.error("sg200 Test: " + msg)
        response["succeeded"] = False
        response["troubleshooting"] = msg
    else:
        base_url = f"{collector_proto}://{collector_host}:{collector_port}/sg200/mac-table"
        params_dict = {"ip": test_ip}
        if sg200_username and sg200_password:
            params_dict["user"] = sg200_username
            params_dict["pass"] = sg200_password

        try:
            logging.debug(
                "sg200 Test: contacting collector at [%s] for switch [%s]",
                base_url,
                test_ip,
            )
            resp = requests.get(base_url, params=params_dict, timeout=30)
        except requests.exceptions.RequestException as e:
            msg = f"Error contacting collector: {e}"
            logging.error("sg200 Test: " + msg)
            response["succeeded"] = False
            response["troubleshooting"] = msg
        else:
            if resp.status_code != 200:
                msg = f"Collector returned HTTP {resp.status_code} for switch {test_ip}."
                logging.error("sg200 Test: " + msg)
                response["succeeded"] = False
                response["troubleshooting"] = msg
            else:
                try:
                    data = resp.json()
                except ValueError:
                    msg = "Collector response is not valid JSON."
                    logging.error("sg200 Test: " + msg)
                    response["succeeded"] = False
                    response["troubleshooting"] = msg
                else:
                    entries = data.get("entries", [])
                    if isinstance(entries, list):
                        count = len(entries)
                        msg = (
                            "Successfully contacted collector and retrieved "
                            f"{count} MAC table entries from SG200 {test_ip}."
                        )
                        logging.info("sg200 Test: " + msg)
                        response["succeeded"] = True
                        response["result_msg"] = msg
                    else:
                        msg = "Collector JSON does not contain a list under 'entries'."
                        logging.error("sg200 Test: " + msg)
                        response["succeeded"] = False
                        response["troubleshooting"] = msg

logging.debug("sg200 Test response: %s", response)
logging.info("===> Ending sg200 Test Script")
