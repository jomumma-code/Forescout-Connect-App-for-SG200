import logging
import requests

logging.info("===> Starting sg200 Poll Script")

# Debug params (disable in production if noisy)
logging.debug("Params for sg200 Poll Script:")
logging.debug(params)

# Forescout expects a global 'response' object
response = {}
endpoints = []

collector_host = (params.get("connect_ciscosg200_collector_host") or "").strip()
collector_port = str(params.get("connect_ciscosg200_collector_port") or "").strip()
collector_proto = (params.get("connect_ciscosg200_collector_protocol") or "http").strip().lower()
switch_list = (params.get("connect_ciscosg200_switch_list") or "").strip()

# Optional – same credentials for all SG200 switches; only used if you
# add these fields to system.conf as connect_ciscosg200_username/password
sg200_username = (params.get("connect_ciscosg200_username") or "").strip()
sg200_password = (params.get("connect_ciscosg200_password") or "").strip()

if not collector_host or not collector_port:
    msg = "Missing collector host or port configuration."
    logging.error("sg200 Poll: " + msg)
    response["error"] = msg

elif not switch_list:
    msg = "No SG200 switches configured (connect_ciscosg200_switch_list is empty)."
    logging.error("sg200 Poll: " + msg)
    response["error"] = msg

else:
    base_url = f"{collector_proto}://{collector_host}:{collector_port}/sg200/mac-table"

    for raw_ip in switch_list.split(","):
        switch_ip = raw_ip.strip()
        if not switch_ip:
            continue

        params_dict = {"ip": switch_ip}
        if sg200_username and sg200_password:
            params_dict["user"] = sg200_username
            params_dict["pass"] = sg200_password

        try:
            logging.debug(
                "sg200 Poll: requesting MAC table for switch [%s] from collector [%s]",
                switch_ip,
                base_url,
            )
            resp = requests.get(base_url, params=params_dict, timeout=30)
        except requests.exceptions.RequestException as e:
            logging.error(
                "sg200 Poll: error contacting collector for %s: %s",
                switch_ip,
                e,
            )
            continue

        if resp.status_code != 200:
            logging.error(
                "sg200 Poll: collector returned HTTP %s for %s",
                resp.status_code,
                switch_ip,
            )
            continue

        try:
            data = resp.json()
        except ValueError:
            logging.error(
                "sg200 Poll: invalid JSON from collector for %s: %s",
                switch_ip,
                resp.text[:200],
            )
            continue

        entries = data.get("entries", [])
        if not isinstance(entries, list):
            logging.error("sg200 Poll: 'entries' is not a list for %s", switch_ip)
            continue

        for entry in entries:
            mac = entry.get("mac")
            vlan = entry.get("vlan")
            port_index = entry.get("port_index")

            if not mac:
                continue

            # Normalize MAC for Forescout: no separators, lower-case
            mac_hex = mac.replace(":", "").replace("-", "").lower()

            endpoint = {"mac": mac_hex}
            props = {
                "connect_ciscosg200_switch_ip": switch_ip
            }
            if vlan is not None:
                props["connect_ciscosg200_vlan"] = str(vlan)
            if port_index is not None:
                props["connect_ciscosg200_port_index"] = str(port_index)

            endpoint["properties"] = props
            endpoints.append(endpoint)

    if endpoints:
        response["endpoints"] = endpoints
    else:
        if "error" not in response:
            response["error"] = "No endpoints collected from SG200 collector."

logging.debug("sg200 Poll response: %s", response)
logging.info("===> Ending sg200 Poll Script")
