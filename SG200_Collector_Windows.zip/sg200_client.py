#!/usr/bin/env python3
"""
sg200_client.py

Headless login + scrape of SG200 Dynamic MAC table using Playwright.

Returns entries:
  [{"switch_ip": "...", "vlan": 1, "mac": "aa:bb:..", "port_index": 52}, ...]

Design:
  - Tries HTTPS first (ignore_https_errors=True), then falls back to HTTP.
  - Detects the /csbXXXXXX/ prefix post-login by scanning frame URLs.
  - Navigates directly to:
      /<prefix>/Adrs_tbl/bridg_frdData_dynamicAddress_m.htm
  - Parses dot1q* hidden inputs.
"""

import re
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError


NAV_TIMEOUT_MS = 15000


def _perform_login(page, username, password):
    # Find a frame that contains a password field.
    login_frame = None
    for frame in page.frames:
        pw = frame.query_selector("input[type='password']")
        if pw is not None:
            login_frame = frame
            break

    if login_frame is None:
        # Could already be logged in
        return

    pw = login_frame.query_selector("input[type='password']")
    user = login_frame.query_selector("input[type='text'], input[type='email']")
    if user is None:
        user = login_frame.query_selector("input:not([type='password'])")

    if user is None or pw is None:
        raise RuntimeError("Could not locate username/password fields")

    user.fill(username)
    pw.fill(password)

    btn = login_frame.query_selector("input[type='submit'], button, input[type='button']")
    if btn is not None:
        btn.click()
    else:
        pw.press("Enter")

    page.wait_for_timeout(3000)


def _detect_csb_prefix(page):
    pattern = re.compile(r"/(csb[0-9a-fA-F]+)/")
    for frame in page.frames:
        m = pattern.search(frame.url)
        if m:
            return m.group(1)
    m = pattern.search(page.url)
    if m:
        return m.group(1)
    raise RuntimeError("Could not detect csbXXXXXX prefix after login")


def _parse_dynamic_mac_table(html, switch_ip):
    soup = BeautifulSoup(html, "html.parser")
    inputs = soup.find_all("input")

    vlan_by_idx = {}
    mac_by_idx = {}
    port_by_idx = {}

    for inp in inputs:
        name = inp.get("name")
        if not name:
            continue
        value = (inp.get("value") or "").strip()

        if name.startswith("dot1qFdbId$repeat?"):
            idx = name.split("?", 1)[1]
            try:
                vlan_by_idx[idx] = int(value)
            except Exception:
                continue
        elif name.startswith("dot1qTpFdbAddress$repeat?"):
            idx = name.split("?", 1)[1]
            mac_by_idx[idx] = value
        elif name.startswith("dot1qTpFdbPort$repeat?"):
            idx = name.split("?", 1)[1]
            try:
                port_by_idx[idx] = int(value)
            except Exception:
                continue

    entries = []
    for idx in sorted(mac_by_idx.keys(), key=lambda x: int(x)):
        mac_hex = mac_by_idx.get(idx)
        vlan = vlan_by_idx.get(idx)
        port_index = port_by_idx.get(idx)
        if not mac_hex or vlan is None or port_index is None:
            continue
        mac_hex = mac_hex.lower()
        if len(mac_hex) == 12:
            mac_fmt = ":".join(mac_hex[i:i + 2] for i in range(0, 12, 2))
        else:
            # fallback
            mac_fmt = mac_hex

        entries.append(
            {
                "switch_ip": switch_ip,
                "vlan": vlan,
                "mac": mac_fmt,
                "port_index": port_index,
            }
        )
    return entries


def fetch_mac_table(switch_ip, username, password):
    """
    Main collector API call: log in and return Dynamic MAC table entries.
    """
    schemes = ["https", "http"]

    last_err = None

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(ignore_https_errors=True)
        page = context.new_page()

        prefix = None
        for scheme in schemes:
            base_url = f"{scheme}://{switch_ip}/"
            try:
                page.goto(base_url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
                _perform_login(page, username, password)
                prefix = _detect_csb_prefix(page)
                base_url = f"{scheme}://{switch_ip}/"
                dyn_url = urljoin(base_url, f"{prefix}/Adrs_tbl/bridg_frdData_dynamicAddress_m.htm")
                page.goto(dyn_url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
                html = page.content()
                entries = _parse_dynamic_mac_table(html, switch_ip)
                browser.close()
                return entries
            except Exception as e:
                last_err = e
                continue

        browser.close()

    raise RuntimeError("Both HTTPS and HTTP attempts failed: %s" % last_err)
