#!/usr/bin/env python3
"""
SG200 collector API (Flask).

Endpoints:
  GET  /health
  POST /sg200/mac-table   JSON: {"ip": "...", "user": "...", "pass": "..."}
  GET  /sg200/mac-table   (legacy) query params ip/user/pass

Auth:
  If env var SG200_COLLECTOR_TOKEN is set, the caller must supply header:
      X-SG200-Token: <token>

Notes:
  - This collector must be run on a host that has Playwright installed (and the Chromium browser downloaded).
  - SG200 itself is HTTP-only, so the collector to SG200 traffic is unencrypted.
"""

import logging
import os

from flask import Flask, request, jsonify

from sg200_client import fetch_mac_table

app = Flask(__name__)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def _require_token_if_configured():
    expected = os.environ.get("SG200_COLLECTOR_TOKEN", "").strip()
    if not expected:
        return None

    provided = request.headers.get("X-SG200-Token", "").strip()
    if not provided or provided != expected:
        return jsonify({"error": "unauthorized"}), 401
    return None


@app.route("/health", methods=["GET"])
def health():
    deny = _require_token_if_configured()
    if deny:
        return deny
    return jsonify({"status": "ok"})


@app.route("/sg200/mac-table", methods=["GET", "POST"])
def mac_table():
    deny = _require_token_if_configured()
    if deny:
        return deny

    if request.method == "POST":
        payload = request.get_json(silent=True) or {}
        switch_ip = payload.get("ip")
        username = payload.get("user")
        password = payload.get("pass")
    else:
        switch_ip = request.args.get("ip")
        username = request.args.get("user")
        password = request.args.get("pass")

    if not switch_ip or not username or not password:
        return jsonify({"error": "ip, user, pass are required"}), 400

    logger.info("Request for MAC table from %s", switch_ip)

    try:
        entries = fetch_mac_table(switch_ip, username, password)
    except Exception as e:
        logger.exception("Error fetching MAC table from %s: %s", switch_ip, e)
        return jsonify({"error": str(e)}), 500

    return jsonify({"switch_ip": switch_ip, "entries": entries})


if __name__ == "__main__":
    host = os.environ.get("SG200_COLLECTOR_HOST", "0.0.0.0")
    port = int(os.environ.get("SG200_COLLECTOR_PORT", "8080"))
    app.run(host=host, port=port)
