# -*- coding: utf-8 -*-
"""
Cisco SG200 (proxy collector) - Connect discovery/poll script.

For the configured SG200 switch:
  - Calls the collector to retrieve the Dynamic MAC table.
  - Emits one endpoint per MAC address with SG200 properties attached.

Security notes:
  - Collector communication is HTTP by design (SG200 itself is HTTP-only).
  - Credentials are sent to the collector via POST (not query params) to reduce exposure in logs.
  - Optionally supports a shared token header (X-SG200-Token).
"""

import logging

from sg200_common import _normalize_base_url, collector_fetch_mac_table

logger = logging.getLogger(__name__)


def _get_param(key, required=True, default=None):
    val = params.get(key)  # provided by Connect runtime
    if val is None or val == "":
        if required:
            raise ValueError("Missing required system parameter: %s" % key)
        return default
    return val


def _normalize_mac(mac):
    m = (mac or "").strip().lower()
    if not m:
        return None
    # allow "aabbccddeeff" or "aa:bb:cc:dd:ee:ff"
    if ":" not in m and len(m) == 12:
        m = ":".join([m[i:i+2] for i in range(0, 12, 2)])
    return m


response = {"endpoints": []}

try:
    collector_host = _get_param("connect_ciscosg200_collector_host")
    collector_port = _get_param("connect_ciscosg200_collector_port", required=False, default="8080")
    collector_token = _get_param("connect_ciscosg200_collector_token", required=False, default="")

    switch_ip = _get_param("connect_ciscosg200_switch_ip")
    switch_user = _get_param("connect_ciscosg200_switch_username")
    switch_pass = _get_param("connect_ciscosg200_switch_password")

    base_url = _normalize_base_url(collector_host, collector_port)
    data = collector_fetch_mac_table(
        base_url,
        switch_ip=switch_ip,
        username=switch_user,
        password=switch_pass,
        token=collector_token,
    )

    entries = data.get("entries", [])
    endpoints = []

    for ent in entries:
        mac = _normalize_mac(ent.get("mac"))
        if not mac:
            continue

        vlan = ent.get("vlan")
        port_index = ent.get("port_index")

        endpoint = {
            "mac": mac,
            "properties": {
                "connect_ciscosg200_switch_ip": str(switch_ip),
                "connect_ciscosg200_vlan": "" if vlan is None else str(vlan),
                "connect_ciscosg200_port_index": "" if port_index is None else str(port_index),
            },
        }
        endpoints.append(endpoint)

    response["endpoints"] = endpoints

except Exception as e:
    logger.exception("SG200 poll failed: %s", e)
    response["error"] = str(e)
