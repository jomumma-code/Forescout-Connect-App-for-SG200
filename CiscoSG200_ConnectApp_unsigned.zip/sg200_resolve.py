# -*- coding: utf-8 -*-
"""
Cisco SG200 (proxy collector) - property resolve script.

Given an endpoint MAC, attempts to find it in the configured switch's Dynamic MAC table,
and returns SG200 properties.

This also eliminates Connect import warnings about "property has no matching script and will not be resolvable".
"""

import logging

from sg200_common import _normalize_base_url, collector_fetch_mac_table

logger = logging.getLogger(__name__)


def _get_param(key, required=True, default=None):
    val = params.get(key)  # provided by Connect runtime
    if val is None or val == "":
        if required:
            raise ValueError("Missing required parameter: %s" % key)
        return default
    return val


def _get_endpoint_mac():
    for k in ("mac", "mac_address", "endpoint_mac", "macAddress"):
        v = params.get(k)
        if v:
            return v
    return None


def _normalize_mac(mac):
    m = (mac or "").strip().lower()
    if not m:
        return None
    if ":" not in m and len(m) == 12:
        m = ":".join([m[i:i+2] for i in range(0, 12, 2)])
    return m


response = {"properties": {}}

try:
    collector_host = _get_param("connect_ciscosg200_collector_host")
    collector_port = _get_param("connect_ciscosg200_collector_port", required=False, default="8080")
    collector_token = _get_param("connect_ciscosg200_collector_token", required=False, default="")

    switch_ip = _get_param("connect_ciscosg200_switch_ip")
    switch_user = _get_param("connect_ciscosg200_switch_username")
    switch_pass = _get_param("connect_ciscosg200_switch_password")

    target_mac = _normalize_mac(_get_endpoint_mac())
    if not target_mac:
        raise ValueError("No endpoint MAC was provided to resolve against")

    base_url = _normalize_base_url(collector_host, collector_port)
    data = collector_fetch_mac_table(
        base_url,
        switch_ip=switch_ip,
        username=switch_user,
        password=switch_pass,
        token=collector_token,
    )

    match = None
    for ent in data.get("entries", []):
        if _normalize_mac(ent.get("mac")) == target_mac:
            match = ent
            break

    props = {
        "connect_ciscosg200_switch_ip": str(switch_ip),
    }

    if match:
        vlan = match.get("vlan")
        port_index = match.get("port_index")
        props["connect_ciscosg200_vlan"] = "" if vlan is None else str(vlan)
        props["connect_ciscosg200_port_index"] = "" if port_index is None else str(port_index)
        response["result_msg"] = "Resolved SG200 MAC table entry for %s" % target_mac
    else:
        response["result_msg"] = "MAC %s not present in SG200 Dynamic MAC table for switch %s" % (target_mac, switch_ip)

    response["properties"] = props
    response["succeeded"] = True

except Exception as e:
    logger.exception("SG200 resolve failed: %s", e)
    response["succeeded"] = False
    response["error"] = str(e)
