# -*- coding: utf-8 -*-
"""
Cisco SG200 (proxy collector) - Connect test script.

Validates:
  1) Collector reachable (/health)
  2) Collector can fetch the switch MAC table for the configured switch
"""

import logging

from sg200_common import _normalize_base_url, collector_health, collector_fetch_mac_table

logger = logging.getLogger(__name__)


def _get_param(key, required=True, default=None):
    val = params.get(key)  # provided by Connect runtime
    if val is None or val == "":
        if required:
            raise ValueError("Missing required system parameter: %s" % key)
        return default
    return val


response = {}

try:
    collector_host = _get_param("connect_ciscosg200_collector_host")
    collector_port = _get_param("connect_ciscosg200_collector_port", required=False, default="8080")
    collector_token = _get_param("connect_ciscosg200_collector_token", required=False, default="")

    switch_ip = _get_param("connect_ciscosg200_switch_ip")
    switch_user = _get_param("connect_ciscosg200_switch_username")
    switch_pass = _get_param("connect_ciscosg200_switch_password")

    base_url = _normalize_base_url(collector_host, collector_port)

    health = collector_health(base_url, token=collector_token)
    if not isinstance(health, dict) or health.get("status") != "ok":
        raise RuntimeError("Collector healthcheck failed: %r" % health)

    data = collector_fetch_mac_table(
        base_url,
        switch_ip=switch_ip,
        username=switch_user,
        password=switch_pass,
        token=collector_token,
    )

    entries = data.get("entries", [])
    response["succeeded"] = True
    response["result_msg"] = "Collector OK. Switch %s MAC entries fetched: %d" % (switch_ip, len(entries))

except Exception as e:
    logger.exception("SG200 test failed: %s", e)
    response["succeeded"] = False
    response["error"] = str(e)
