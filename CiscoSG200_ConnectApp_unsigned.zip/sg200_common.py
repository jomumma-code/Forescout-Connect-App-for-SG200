import json
import logging
from urllib.parse import urlsplit, urlunsplit

import requests

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT_SEC = 20


def _normalize_base_url(host, port):
    """
    Accept either:
      - "collector.example.com" + 8080
      - "http://collector.example.com" + 8080
      - "http://collector.example.com:8080" (port ignored)
    Returns a base like "http://collector.example.com:8080".
    """
    host = (host or "").strip()
    port = (str(port or "")).strip()

    if not host:
        raise ValueError("Collector host is empty")

    if "://" not in host:
        # Default to HTTP (no TLS by design here)
        host = "http://" + host

    parts = urlsplit(host)
    scheme = parts.scheme or "http"
    netloc = parts.netloc or parts.path  # urlsplit quirk if no path
    path = ""  # base only

    # If host already includes a port, keep it; otherwise append provided port.
    if ":" not in netloc and port:
        netloc = f"{netloc}:{port}"

    return urlunsplit((scheme, netloc, path, "", ""))


def _auth_headers(token):
    h = {}
    token = (token or "").strip()
    if token:
        h["X-SG200-Token"] = token
    return h


def collector_health(base_url, token=None, timeout=DEFAULT_TIMEOUT_SEC):
    url = base_url.rstrip("/") + "/health"
    r = requests.get(url, headers=_auth_headers(token), timeout=timeout)
    r.raise_for_status()
    return r.json()


def collector_fetch_mac_table(base_url, switch_ip, username, password, token=None, timeout=DEFAULT_TIMEOUT_SEC):
    """
    Prefer POST to keep credentials out of URLs/logs. Collector supports GET fallback for backwards compatibility.
    """
    url = base_url.rstrip("/") + "/sg200/mac-table"
    payload = {"ip": switch_ip, "user": username, "pass": password}
    r = requests.post(url, json=payload, headers=_auth_headers(token), timeout=timeout)
    if r.status_code == 405:
        # Legacy collector may only support GET
        r = requests.get(url, params=payload, headers=_auth_headers(token), timeout=timeout)

    r.raise_for_status()
    return r.json()
